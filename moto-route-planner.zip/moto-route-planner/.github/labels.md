# Метки (создать в репозитории)
- Тип: `type:feature`, `type:bug`, `type:research`, `type:docs`, `type:chore`
- Приоритет: `P0`, `P1`, `P2`
- Эпик: `epic:foundation`, `epic:route`, `epic:moto-calc`, `epic:export-share`, `epic:moto-modes`, `epic:poi`, `epic:accounts`, `epic:marketing`, `epic:process`
- Статус: `blocked`, `needs-decision`
